/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: slavusworks
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `case_studies`
--

DROP TABLE IF EXISTS `case_studies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_studies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `core_problem` text NOT NULL,
  `solution` text NOT NULL,
  `technologies_used` text DEFAULT NULL,
  `results` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_studies`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `case_studies` WRITE;
/*!40000 ALTER TABLE `case_studies` DISABLE KEYS */;
INSERT INTO `case_studies` VALUES
(2,'HL-Web App N Booking System','SMAN 1 Bukittinggi','5 Months','<ul>\r\n  <li>The event registration system was still handled manually using separate Google Forms for each event, making it difficult to manage multiple events efficiently.</li>\r\n  \r\n  <li>Financial bookkeeping and accounting processes were still done manually, increasing the risk of recording errors and reducing transparency.</li>\r\n  \r\n  <li>Participant, payment, and reporting data were scattered across multiple spreadsheets, making monitoring and data management inefficient.</li>\r\n  \r\n  <li>The re-registration process was still conducted manually, causing longer queues and slower participant validation.</li>\r\n  \r\n  <li>There was a high risk of duplicate or double data input caused by participant or administrator input errors.</li>\r\n</ul>','<ul>\r\n  <li>Developed a centralized web-based registration system that manages all events within a single platform.</li>\r\n  \r\n  <li>Built a dynamic event management dashboard that allows administrators to create, organize, and monitor multiple events from one system.</li>\r\n  \r\n  <li>Implemented a real-time participant monitoring dashboard to simplify data tracking and management.</li>\r\n  \r\n  <li>Integrated financial bookkeeping and accounting features into the application to improve transparency and simplify auditing processes.</li>\r\n  \r\n  <li>Created a digital re-registration system to speed up participant validation during events.</li>\r\n  \r\n  <li>Added automated data validation features to minimize input errors and prevent duplicate data entries.</li>\r\n</ul>','Laravel,PHP,Tailwind CSS,Javascript,Node.JS,Ajax,MySQL,Nginx,Git,Ubuntu Server,Cloudflare','<ul>\r\n  <li>All event registration processes became more organized and centralized.</li>\r\n  \r\n  <li>Administrators were able to manage multiple events more efficiently through one integrated dashboard.</li>\r\n  \r\n  <li>Participant monitoring became faster, more accurate, and easier to access in real time.</li>\r\n  \r\n  <li>Financial transparency, all transactions could be monitored directly through the dashboard. </li>\r\n      \r\n  <li>Operational efficiency increased as data management. </li>\r\n</ul>',NULL,'2026-05-25 19:15:17','2026-05-25 19:34:04');
/*!40000 ALTER TABLE `case_studies` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `case_study_images`
--

DROP TABLE IF EXISTS `case_study_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_study_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `case_study_id` bigint(20) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `case_study_images_case_study_id_foreign` (`case_study_id`),
  CONSTRAINT `case_study_images_case_study_id_foreign` FOREIGN KEY (`case_study_id`) REFERENCES `case_studies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_study_images`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `case_study_images` WRITE;
/*!40000 ALTER TABLE `case_study_images` DISABLE KEYS */;
INSERT INTO `case_study_images` VALUES
(4,2,'case_studies/54VAH7NvIl9cRAHlcfFS1vcHa3bhuaOPSEHW60Sr.png','2026-05-25 19:15:17','2026-05-25 19:15:17'),
(5,2,'case_studies/i7PFQ1oMajRBORte551cdWtAkZeXvcc2Lj50XtXc.png','2026-05-25 19:15:17','2026-05-25 19:15:17'),
(6,2,'case_studies/zFZfk1OLMhrwRPiWcUQ93W0gmpXM39n43nuYmBIk.png','2026-05-25 19:15:17','2026-05-25 19:15:17'),
(7,2,'case_studies/QmvsZNRrQAFg8xJe7zKp1OSx5ChI9A6lN94TqKfs.png','2026-05-25 19:15:17','2026-05-25 19:15:17'),
(8,2,'case_studies/Fiim0otzy8Qam2oi7xAZ38fkHeeFNUyfZVUA7GU9.jpg','2026-05-25 19:39:21','2026-05-25 19:39:21'),
(9,2,'case_studies/huhxmA4r0bo6wuqMnoOPyrElyiv3K095HyBjFBpL.jpg','2026-05-25 19:39:21','2026-05-25 19:39:21');
/*!40000 ALTER TABLE `case_study_images` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `experience`
--

DROP TABLE IF EXISTS `experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `job_title` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `job_position` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `experience` WRITE;
/*!40000 ALTER TABLE `experience` DISABLE KEYS */;
INSERT INTO `experience` VALUES
(1,'2023-07-01 13:44:00','2026-05-01 13:45:00','High School Diploma','Education','SMAN 1 Bukittinggi','General Science','Accumulative Average Score: 91,13','2026-05-24 23:45:15','2026-05-25 00:00:34'),
(2,'2024-11-25 13:47:00','2025-11-25 13:47:00','IT Extracurricular Leader','Volunteer','SMAN 1 Bukittinggi','Landbouw Engineering Informatic Virtualizing Organization','Flagship Programs: Technology Booth Coordinator, First Robotic Training Program in SMAN 1 Bukittinggi.','2026-05-24 23:47:41','2026-05-25 06:25:52'),
(3,'2025-07-01 13:56:00','2025-11-01 13:56:00','Ethical Hacker','Training','Cisco Networking Academy','Certified Completed Course',NULL,'2026-05-24 23:57:12','2026-05-24 23:57:12'),
(4,'2024-12-01 13:58:00','2024-12-17 13:58:00','AI Engineer for Millennial','Training','Badan Pengembangan SDM Kominfo - MicroSkill','Certified Completed Course',NULL,'2026-05-24 23:58:41','2026-05-24 23:58:41'),
(5,'2024-01-01 14:10:00',NULL,'Fullstack Web Developer','Work','SLAVUSworks','Self-Employment',NULL,'2026-05-25 00:10:12','2026-05-25 00:10:12'),
(6,'2023-01-01 14:10:00',NULL,'IT Support Specialist','Work','SLAVUSworks','Self-Employment',NULL,'2026-05-25 00:10:46','2026-05-25 00:10:46'),
(7,'2024-05-01 08:32:00',NULL,'Project Initiative','Volunteer','SBcRID','Kantai Collection Game Localization Community Project','My roles including, DevOps Engineer, Team Management, Web Developer.','2026-05-25 18:34:48','2026-05-25 18:34:48');
/*!40000 ALTER TABLE `experience` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `landing_windows`
--

DROP TABLE IF EXISTS `landing_windows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_windows` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `subheading` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_windows`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `landing_windows` WRITE;
/*!40000 ALTER TABLE `landing_windows` DISABLE KEYS */;
INSERT INTO `landing_windows` VALUES
(1,'welcome','Hello There!','img/landing/yhn00vUvZsd8WbQYNd5BMZ73Xx8eNSKQJrf2S2MU.png','Portfolio Site','Thank You for Visiting \"Abdurrahman Agha Rabbani\"; Personal Portfolio Website','Welcome, Bienvenido, Bienvenue, Willkommen, Benvenuto, Bem-vindo, Welkom, Välkommen, Velkommen, Velkommen, Tervetuloa, Velkomin, Witamy, Vítejte, Vitaj, Üdvözöljük, Bun venit, Καλώς ήρθατε, Hoş geldiniz, Добро пожаловать, Ласкаво просимо, Добре дошли, Добродошли, Dobrodošli, Dobrodošli, Dobrodošli, أهلا وسهلا, ברוכים הבאים, خوش آمدید, स्वागतम्, خوش آمدید, স্বাগতম, स्वागत छ, ආයුබෝවන්, ยินดีต้อนรับ, ຍິນດີຕ້ອນຮັບ, Chào mừng, Selamat datang, Maligayang pagdating, 欢迎, 歡迎, ようこそ, 환영합니다, Тавтай морил, Karibu, Siyakwamukela, Wamkelekile, Welkom, Bonvenon','2026-05-22 02:31:27','2026-05-25 19:42:03'),
(2,'contact','Contact','img/landing/2P9A2TIcxN39YNARnvXgng7fU2UOcBFEbCB0QabT.png','Contact Me!','Feel free to reach out to me for friendship or business opportunities, I\'m always looking for more connections.','<div class=\"grid grid-cols-1 md:grid-cols-2 gap-3 mt-6\">\r\n\r\n  <div class=\"bg-[#dcdcdc] \r\n              border-t-2 border-l-2 border-white \r\n              border-r-2 border-b-2 border-r-black border-b-black\r\n              px-3 py-2\">\r\n    \r\n    <h3 class=\"font-bold text-sm mb-1\">Email</h3>\r\n    <a href=\"mailto:abdurrahmanagharabbani45@gmail.com\" \r\n       class=\"text-xs underline hover:text-blue-700\">\r\n      abdurrahmanagharabbani45@gmail.com\r\n    </a>\r\n\r\n  </div>\r\n\r\n  <div class=\"bg-[#dcdcdc] \r\n              border-t-2 border-l-2 border-white \r\n              border-r-2 border-b-2 border-r-black border-b-black\r\n              px-3 py-2\">\r\n    \r\n    <h3 class=\"font-bold text-sm mb-1\">Instagram</h3>\r\n    <a href=\"https://instagram.com/aghaslavus\" target=\"_blank\"\r\n       class=\"text-xs underline hover:text-blue-700\">\r\n      @aghaslavus\r\n    </a>\r\n\r\n  </div>\r\n\r\n  <div class=\"bg-[#dcdcdc] \r\n              border-t-2 border-l-2 border-white \r\n              border-r-2 border-b-2 border-r-black border-b-black\r\n              px-3 py-2\">\r\n    \r\n    <h3 class=\"font-bold text-sm mb-1\">Github</h3>\r\n    <a href=\"https://github.com/SLAVUSworks\" target=\"_blank\"\r\n       class=\"text-xs underline hover:text-blue-700\">\r\n      github.com/SLAVUSworks\r\n    </a>\r\n\r\n  </div>\r\n\r\n  <div class=\"bg-[#dcdcdc] \r\n              border-t-2 border-l-2 border-white \r\n              border-r-2 border-b-2 border-r-black border-b-black\r\n              px-3 py-2\">\r\n    \r\n    <h3 class=\"font-bold text-sm mb-1\">Website</h3>\r\n    <a href=\"https://slavusworks.my.id\" target=\"_blank\"\r\n       class=\"text-xs underline hover:text-blue-700\">\r\n      slavusworks.my.id\r\n    </a>\r\n\r\n  </div>\r\n\r\n  <div class=\"bg-[#dcdcdc] \r\n              border-t-2 border-l-2 border-white \r\n              border-r-2 border-b-2 border-r-black border-b-black\r\n              px-3 py-2\">\r\n    \r\n    <h3 class=\"font-bold text-sm mb-1\">LinkedIn</h3>\r\n    <a href=\"https://linkedin.com/in/aghaslavus\" target=\"_blank\"\r\n       class=\"text-xs underline hover:text-blue-700\">\r\n      linkedin.com/in/aghaslavus\r\n    </a>\r\n\r\n  </div>\r\n\r\n  <div class=\"bg-[#dcdcdc] \r\n              border-t-2 border-l-2 border-white \r\n              border-r-2 border-b-2 border-r-black border-b-black\r\n              px-3 py-2\">\r\n    \r\n    <h3 class=\"font-bold text-sm mb-1\">X</h3>\r\n    <a href=\"https://x.com/AghaSlavus\" target=\"_blank\"\r\n       class=\"text-xs underline hover:text-blue-700\">\r\n      x.com/AghaSlavus\r\n    </a>\r\n\r\n  </div>\r\n\r\n</div>','2026-04-13 13:35:31','2026-04-13 13:57:31'),
(3,'slapusworks','SLAVUSworks','img/landing/ZF5bTT8y2Zs1TSsctfGvHi8SrJeI3D1wRwXOQL3T.png','What is SLAVUSworks?','Our Team Overview','SLAVUSworks is a small creative tech team building cool systems, digital tools, and creative projects by blending engineering, design, and experimental ideas into one connected workflow. Contributes to both technical and creative sides, focusing on building things that are functional, practical, and expressive.','2026-04-13 14:03:43','2026-04-13 14:05:21'),
(4,'bio','Who Am I?','img/landing/K7XluD95qH9aC4JnIPbLpIpMK7WQ8nUc5BKDQzUK.png','Abdurrahman Agha Rabbani','You can call me \"Agha\".','Web Developer & IT Support Technician with experience in full-stack web development, server management, and hardware troubleshooting. Skilled in Laravel, PHP, JavaScript, Tailwind CSS, Linux server administration, and Git-based workflows. Passionate about cybersecurity, AI, and open-source projects. Currently leading SLAVUSworks while working on freelance development and IT support projects.','2026-04-13 14:09:50','2026-04-13 14:12:19');
/*!40000 ALTER TABLE `landing_windows` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_06_22_001806_create_landing_windows_table',1),
(5,'2025_06_22_020036_create_projects_windows_table',1),
(6,'2025_06_30_064124_create_skills_table',1),
(8,'2025_07_07_035529_create_case_studies_table',1),
(9,'2025_07_07_041118_create_case_study_images_table',1),
(10,'2025_07_06_065127_create_experience_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `projects_windows`
--

DROP TABLE IF EXISTS `projects_windows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_windows` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `stacks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_windows`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `projects_windows` WRITE;
/*!40000 ALTER TABLE `projects_windows` DISABLE KEYS */;
INSERT INTO `projects_windows` VALUES
(1,'HL-Web App N Booking System',2025,'img/projects/lXDKnrYuBQdAk8mF9ExjcZsCsGXWQCxyrqPBsVRB.png','Event management and booking system for Highlandtion event at SMAN 1 Bukittinggi.','Laravel,PHP,Tailwind CSS,Javascript,Node.JS,Ajax,MySQL,Nginx,Git,Ubuntu Server,Cloudflare,CI/CD','2026-04-13 17:41:45','2026-05-24 23:21:10'),
(2,'Project KanColle Patch Indonesia',2024,'img/projects/AoUdFrwIzY0TzShBM458Ioh40S5iexN0BieEWX57.png','Localization project in Web Game Kantai Collection (Community Project) from English to Bahasa Indonesia.','Team Management,Advance CI/CD,Quality Assurance,JSON,Photoshop,Batch Script','2026-04-13 17:46:53','2026-04-13 17:46:53'),
(3,'KCID Translation Management System',2026,'img/projects/eRYw3gLs0NG9ni3jc8Zq5Owe5kLcNw7eC1xxmNxb.png','Web-based management system for Project KC Patch Indonesia (Community Project) JSON assets.','Laravel,Tailwind CSS,PHP,MySQL,JSON,Javascript,Claude Code,Nginx,CI/CD,Git,Cloudflare Tunnel','2026-04-13 17:49:27','2026-04-13 17:52:48');
/*!40000 ALTER TABLE `projects_windows` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('Y2Xp1K98lAvXrscabYgtnlFmZmPtDTDjoxodfheB',2,'192.168.100.97','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1 Edg/148.0.0.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiR3FHdHNXc096bzYwQXI5cUNSQkFDbXpRU0hTT1doYzBETmFNd3dsUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8xOTIuMTY4LjEwMC40NTo4MDAwL2Rlc2t0b3AiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyO30=',1779764425);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `skills` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `skills_parent_id_foreign` (`parent_id`),
  CONSTRAINT `skills_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=391 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skills`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `skills` WRITE;
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
INSERT INTO `skills` VALUES
(1,NULL,'IT Tech Stacks','2026-04-13 15:37:14','2026-04-13 15:37:14'),
(230,NULL,'Language Proficiency','2026-04-13 16:14:47','2026-04-13 16:14:47'),
(244,230,'Bahasa Indonesia','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(245,244,'Native Speaker','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(246,230,'English','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(247,246,'Listening: B2','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(248,246,'Reading: B2','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(249,246,'Writing: B2','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(250,246,'Speaking: B1','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(251,230,'German','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(252,251,'Listening: A1','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(253,251,'Reading: A1','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(254,251,'Writing: A1','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(255,251,'Speaking: A1','2026-04-13 16:15:48','2026-04-13 16:15:48'),
(345,1,'Backend and Frontend','2026-05-25 18:21:46','2026-05-25 18:21:46'),
(346,345,'Laravel (Framework)','2026-05-25 18:21:46','2026-05-25 18:21:46'),
(347,345,'PHP','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(348,345,'Python','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(349,345,'MySQL','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(350,345,'Firebase','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(351,345,'HTML/CSS','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(352,345,'Tailwind, Bootstrap','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(353,345,'Javascript','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(354,345,'Node.JS','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(355,1,'Server Management','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(356,355,'Debian Server','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(357,355,'Ubuntu Server','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(358,355,'Proxmox','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(359,355,'Nginx','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(360,355,'Apache','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(361,355,'cPanel / WHM Control','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(362,355,'Cloudflare','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(363,355,'Tailscale','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(364,355,'SSH','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(365,1,'DevOps','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(366,365,'Git','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(367,365,'Github','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(368,365,'Docker (Basic)','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(369,365,'Linux','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(370,365,'Virtual Machine','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(371,1,'Tools','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(372,371,'Visual Studio Code','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(373,371,'Claude Code','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(374,371,'Microsoft Copilot','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(375,371,'Adobe Photoshop','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(376,371,'Google Stitch','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(377,371,'Figma','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(378,371,'Microsoft Office','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(379,371,'VirtualBox','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(380,1,'Support','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(381,380,'Network Setup','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(382,380,'IP Addressing','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(383,380,'Tunneling','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(384,380,'OS Installation','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(385,380,'Troubleshooting','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(386,1,'Cyber Security (Basic)','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(387,386,'Burpsuite','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(388,386,'Nmap','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(389,386,'SQLmap','2026-05-25 18:21:47','2026-05-25 18:21:47'),
(390,386,'DirBuster','2026-05-25 18:21:47','2026-05-25 18:21:47');
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Admin User','admin@example.com','2026-05-22 02:23:49','$2y$12$8/BEQ9jqEKurOjgJ2rxWIeZUnoyUg3ux7DfBR65O4BSwB7Rx.oMlK','7uhY5sMzxN','2026-05-22 02:23:49','2026-05-22 02:23:49'),
(2,'Agha Slavus','miharilabs@localhost','2026-05-22 02:27:36','$2y$12$lVR96CtkTsOR2uZPJRMAmOjVXrttc7yLVFpU1WQZdxWcyd.JA2kXy','EqxeqQXhfl','2026-05-22 02:27:37','2026-05-22 02:27:37');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-26 10:04:05
